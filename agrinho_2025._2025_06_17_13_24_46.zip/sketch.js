// Exemplo 2: Abelha voando entre flor (campo) e telhado (cidade)

let florX, florY;
let telhadoX, telhadoY;
let abelhaX, abelhaY;
let velocidadeAbelha = 2;
let indoParaCidade = false;

function setup() {
  createCanvas(600, 400);
  florX = width * 0.2;
  florY = height * 0.8;
  telhadoX = width * 0.8;
  telhadoY = height * 0.2;
  abelhaX = florX;
  abelhaY = florY;
}

function draw() {
  background(200, 230, 255); // Céu azul claro

  // Desenha o campo
  fill(100, 180, 50); // Verde escuro para a grama
  rect(0, height * 0.7, width, height * 0.3);

  // Desenha a flor (campo)
  fill(255, 100, 150); // Pétalas rosa
  ellipse(florX, florY, 40, 40);
  fill(255, 200, 0); // Centro amarelo
  ellipse(florX, florY, 15, 15);
  fill(100, 150, 50); // Caule
  rect(florX - 2, florY + 20, 4, 30);


  // Desenha a cidade (simplificado)
  fill(150); // Cor dos prédios
  rect(telhadoX - 50, telhadoY, 100, height - telhadoY); // Prédio
  fill(100); // Telhado
  triangle(telhadoX - 60, telhadoY, telhadoX + 60, telhadoY, telhadoX, telhadoY - 50);

  // Desenha a abelha
  fill(255, 200, 0); // Corpo amarelo
  ellipse(abelhaX, abelhaY, 15, 15);
  fill(0); // Listras pretas
  rect(abelhaX - 7, abelhaY - 2, 3, 4);
  rect(abelhaX + 4, abelhaY - 2, 3, 4);
  fill(200, 200, 255, 150); // Asas translúcidas
  ellipse(abelhaX - 5, abelhaY - 10, 8, 15);
  ellipse(abelhaX + 5, abelhaY - 10, 8, 15);

  // Movimento da abelha
  if (!indoParaCidade) {
    abelhaX += velocidadeAbelha;
    abelhaY += sin(frameCount * 0.05) * 2; // Movimento ondulatório
    if (dist(abelhaX, abelhaY, telhadoX, telhadoY) < 50) {
      indoParaCidade = true;
    }
  } else {
    abelhaX -= velocidadeAbelha;
    abelhaY += cos(frameCount * 0.05) * 2; // Movimento ondulatório
    if (dist(abelhaX, abelhaY, florX, florY) < 50) {
      indoParaCidade = false;
    }
  }

  // Texto
  fill(0);
  textSize(24);
  textAlign(CENTER, TOP);
  text("A conexão da abelha: Campo e Cidade", width / 2, 20);
}

// Para testar: Cole este código no editor web do P5.js e execute.